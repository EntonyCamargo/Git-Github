const express = require("express");
const app = express();
const data = require("./data1.json");
app.use(express.json());


  

app.get("/empresa", function(req, res){
    res.json(data);
})



app.get("empresa/:id", function (req, res){
    const { id } = req.params  
    const empresa = data.find(cli => cli.id == id );

    if (!empresa) return res.status(204).json();
 
    res.json(empresa);

})


app.post("/empresa", function (req, res){
    const {name, } = req.body

    res.json({ name});

})

app.put("/empresa/:id", function (req, res){
    const { id } = req.params  
    const empresa = data.find(cli => cli.id == id );

    if (!empresa) return res.status(204).json();
 
    const {name , email } = req.body;

    empresa.name = name;

    empresa.email = email;

    

    res.json(empresa);

})


app.listen(3001, function(){
    console.log("server is running")
    
})
