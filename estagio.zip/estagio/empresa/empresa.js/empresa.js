const url ='https://my-json-server.typicode.com/alexsantraffic/projeto-estagio/empresa'


fetch(url)
.then(Response => Response.json())
.then(data1 =>{
    

    let element =document.getElementById('ID')
    element.innerHTML = '<p>${data.id}</p>';

   
    
    console.log(data1)
})
.catch(err=>console.log(err))


