const url ='https://my-json-server.typicode.com/alexsantraffic/projeto-estagio/parceiro_programatica'


fetch(url)
.then(Response => Response.json())
.then(data2 =>{
    

    let element =document.getElementById('ID')
    element.innerHTML = '<p>${data.id}</p>';

   
    
    console.log(data2)
})
.catch(err=>console.log(err))







