const express = require("express");
const app = express();
const data2 = require("./data2.json");
app.use(express.json());


  

app.get("/analitica",function (req, res){
    res.json(data2);
})



app.get("analitica/:id", function (req, res){
    const { id } = req.params  
    const analitica = data2.find(cli => cli.id == id );

    if (!analitica) return res.status(204).json();
 
    res.json(analitica);

})


app.post("/analitica", function (req, res){
    const {name, } = req.body

    res.json({ name});

})

app.put("/analitica/:id", function (req, res){
    const { id } = req.params  
    const analitica = data2.find(cli => cli.id == id );

    if (!analitica) return res.status(204).json();
 
    const {name , email } = req.body;

    analitica.name = name;

    analitica.email = email;

    

    res.json(analitica);

})


app.listen(3002, function(){
    console.log("server is running")
    
})