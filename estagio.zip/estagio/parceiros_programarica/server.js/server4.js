const express = require("express");
const app = express();
const data4 = require("./data4.json");
app.use(express.json());


  

app.get("/programatica",function (req, res){
    res.json(data4);
})



app.get("programatica/:id", function (req, res){
    const { id } = req.params  
    const programatica = data4.find(cli => cli.id == id );

    if (!programatica) return res.status(204).json();
 
    res.json(programatica);

})


app.post("/programatica", function (req, res){
    const {name, } = req.body

    res.json({ name});

})

app.put("/programatica/:id", function (req, res){
    const { id } = req.params  
    const programatica = data4.find(cli => cli.id == id );

    if (!programatica) return res.status(204).json();
 
    const {name , email } = req.body;

    programatica.name = name;

    programatica.email = email;

    

    res.json(programatica);

})


app.listen(3004, function(){
    console.log("server is running")
    
})