const url ='https://my-json-server.typicode.com/alexsantraffic/projeto-estagio/historico_parceiro'


fetch(url)
.then(Response => Response.json())
.then(data3 =>{
    

    let element =document.getElementById('ID')
    element.innerHTML = '<p>${data.id}</p>';

   
    
    console.log(data3)
})
.catch(err=>console.log(err))