const express = require("express");
const app = express();
const data3 = require("./data3.json");
app.use(express.json());


  

app.get("/parceiro",function (req, res){
    res.json(data3);
})



app.get("parceiro/:id", function (req, res){
    const { id } = req.params  
    const parceiro = data3.find(cli => cli.id == id );

    if (!parceiro) return res.status(204).json();
 
    res.json(parceiro);

})


app.post("/parceiro", function (req, res){
    const {name, } = req.body

    res.json({ name});

})

app.put("/parceiro/:id", function (req, res){
    const { id } = req.params  
    const parceiro = data3.find(cli => cli.id == id );

    if (!parceiro) return res.status(204).json();
 
    const {name , email } = req.body;

    parceiro.name = name;

    parceiro.email = email;

    

    res.json(parceiro);

})


app.listen(3003, function(){
    console.log("server is running")
    
})